package value;

public abstract class ValueClass {
	

}
