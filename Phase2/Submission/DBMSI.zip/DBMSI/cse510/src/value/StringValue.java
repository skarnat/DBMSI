package value;

public class StringValue extends ValueClass{
	
	private String value;
	
	public StringValue() {
		
	}
	
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	
}
