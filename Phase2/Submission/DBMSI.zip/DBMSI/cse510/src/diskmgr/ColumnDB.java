/* File DB.java */

package diskmgr;

public class ColumnDB extends DB {


}
